## Prerequisites

To run this course locally you will need to install node.
Node installers can be found here: https://nodejs.org/en/download/

## Windows Users

To start the course use the `run.cmd` file.

CD into the unzipped folder

From the command prompt enter: run.cmd

## Linux/OSX

To Start the course use the `run.sh` file.

CD into the unzipped folder

From the terminal enter: ./run.sh
