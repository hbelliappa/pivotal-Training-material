function externalLinks() {
  jQuery(document).ready(function($){
    $("a").attr('target', '_blank');
  });
}
