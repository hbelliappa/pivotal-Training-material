<!-- .element: class="textleft-imageright" -->
## Waterscrumfall

![Waterscrumfall](slides/resources/images/waterscrumfall.png "Waterscrumfall")

* Agile practices adopted but only in development
* Waterscrumfall
  * Customers (Lines of Business) revert back waterfall tendencies
  * No feedback in to process
