<!-- .element: class="textleft-imageright" -->

## Silos to DevOps
![Silos to DevOps](slides/resources/images/silos-devops.png "Silos to DevOps")

* Goal: Deliver value rapidly and safely
* Shared vocabulary, tools, and incentive structures
* Bureaucratic processes replaced with trust and accountability
* Common leadership
