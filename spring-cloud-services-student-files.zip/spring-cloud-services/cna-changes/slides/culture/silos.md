<!-- .element: class="textleft-imageright" -->
## Traditional IT Teams

![silos](slides/resources/images/silos.png "silos")

* Grouped by speciality
* Different vocabulary, tools, mgmt, incentive structures
* Different views on the role of IT
* Heavy weight processes to bridge the gap
* Opposed to moving fast

Note:
Discuss the opposing views of Development and Ops
