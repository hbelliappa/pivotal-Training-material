<!-- .element: class="toc" -->

### CNA Changes

* Culture Change <!-- .element: class="current-item" -->
* Organizational Change
* Technical Change

<i class="fa fa-cloud fa-lg"></i>
