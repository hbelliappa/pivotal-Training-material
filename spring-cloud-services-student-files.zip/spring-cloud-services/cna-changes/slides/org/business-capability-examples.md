## Business Capability Teams

![Business Capability Teams](slides/resources/images/example-teams.png "Business Capability Teams")
