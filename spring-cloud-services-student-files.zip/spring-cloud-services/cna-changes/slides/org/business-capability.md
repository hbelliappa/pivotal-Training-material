## Business Capability Teams

![Business Capability Teams](slides/resources/images/business-capability.png "Business Capability Teams")


[http://martinfowler.com/articles/microservices.html#OrganizedAroundBusinessCapabilities](http://martinfowler.com/articles/microservices.html#OrganizedAroundBusinessCapabilities)
