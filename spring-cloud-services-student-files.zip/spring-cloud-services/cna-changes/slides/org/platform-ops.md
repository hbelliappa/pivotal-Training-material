## Platform Operations Teams

![Platform Ops Team](slides/resources/images/platform-team.png "Platform Ops Team")

Adapted from:[http://www.slideshare.net/adriancockcroft/goto-berlin](http://www.slideshare.net/adriancockcroft/goto-berlin)
