## Self Service API

Decoupling - it actually works this time!

![Self Service API](slides/resources/images/selfservice-api.png "Self Service API")

Adapted from:[http://www.slideshare.net/adriancockcroft/goto-berlin](http://www.slideshare.net/adriancockcroft/goto-berlin)
