## Monolithic Approach To Delivery

![Siloed Teams](slides/resources/images/siloed-teams.png "Siloed Teams")


Adapted from:[http://www.slideshare.net/adriancockcroft/goto-berlin](http://www.slideshare.net/adriancockcroft/goto-berlin)
