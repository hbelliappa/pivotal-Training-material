<!-- .element: class="toc" -->

### CNA Changes

* Culture Change
* Organizational Change <!-- .element: class="current-item" -->
* Technical Change

<i class="fa fa-cloud fa-lg"></i>
