## Integration - From Orchestration to Choreography


![Orchestration to Choreography](slides/resources/images/choreography-orchestration.png "Orchestration to Choreography")
