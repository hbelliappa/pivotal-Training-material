## Containers - The New Unit of Deployment

LXC <!-- .element: style="font-size:5em;" -->
![Docker](slides/resources/images/docker.png "Docker") <!-- .element: style="max-width:25%;height:auto;" -->
![Rocket](slides/resources/images/rkt-horizontal-color.png "Rocker") <!-- .element: style="max-width:25%;height:auto;" -->
