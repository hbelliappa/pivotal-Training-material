## Start By Decomposing Data - Bounded Contexts

![Bounded Context](slides/resources/images/bounded-context.png "Bounded Context")
