## Why Decompose Monoliths into Microservices

* Monoliths design patterns not appropriate for the cloud
* Monoliths couple change cycles together
* Monolith services cannot be scaled independently
* Too many developers in one code base
* Developers struggle to understand the codebase
* Long term commitment to tech stack
