## Traditional ESB


![ESB](slides/resources/images/esb.png "ESB")
