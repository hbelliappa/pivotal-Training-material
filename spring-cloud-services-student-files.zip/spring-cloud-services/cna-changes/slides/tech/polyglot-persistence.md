## Polyglot Persistence

![Polyglot Persistence](slides/resources/images/polyglot-persistence.png "Polyglot Persistence")
