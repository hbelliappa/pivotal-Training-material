<!-- .element: class="toc" -->

### CNA Changes

* Culture Change
* Organizational Change
* Technical Change <!-- .element: class="current-item" -->

<i class="fa fa-cloud fa-lg"></i>
