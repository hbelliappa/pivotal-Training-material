## Configure the Dashboard

Enter the the `/hystrix.stream` endpoint.
![Hystrix Dashboard](slides/resources/images/hystrix-dashboard.png "Hystrix Dashboard") <!-- .element: style="border:1px solid black;" -->
