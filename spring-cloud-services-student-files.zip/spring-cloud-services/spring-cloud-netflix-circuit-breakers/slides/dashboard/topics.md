<!-- .element: class="toc" -->

### Spring Cloud Netflix: Circuit Breakers with Hystrix

* Review Fault Tolerance
* Circuit Breakers
* Hystrix Dashboard <!-- .element: class="current-item" -->


<i class="fa fa-cloud fa-lg"></i>
