
## Circuit Breaker Diagram

![circuit breaker](slides/resources/images/diagram.png "circuit breaker")
