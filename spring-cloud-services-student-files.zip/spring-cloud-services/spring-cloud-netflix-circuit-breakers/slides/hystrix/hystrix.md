
## Wrapping Calls With Hystrix

![Circuit Breaker](slides/resources/images/hystrix.png "Circuit Breaker")<!-- .element: style="max-height:600px;" -->
