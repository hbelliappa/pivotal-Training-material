<!-- .element: class="toc" -->

### Spring Cloud Netflix: Circuit Breakers with Hystrix

* Review Fault Tolerance
* Circuit Breakers <!-- .element: class="current-item" -->
* Hystrix Dashboard


<i class="fa fa-cloud fa-lg"></i>
