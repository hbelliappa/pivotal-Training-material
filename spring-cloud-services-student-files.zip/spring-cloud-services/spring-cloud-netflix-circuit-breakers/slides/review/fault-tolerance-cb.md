<!-- .element: class="textleft-imageright" -->



## Fault Tolerance

![Release It](slides/resources/images/release-it.jpg "Release It")

Fault Tolerance Patterns like the _Circuit Breaker_ stop cascading failures.

As described by, Michael T. Nygard in _Release It!_
