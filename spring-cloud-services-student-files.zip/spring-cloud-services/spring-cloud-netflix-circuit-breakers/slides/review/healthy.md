
## Healthy Request Flow

![Healthy System](slides/resources/images/healthy.png "Healthy System")

Source: [https://github.com/Netflix/Hystrix/wiki](https://github.com/Netflix/Hystrix/wiki)
