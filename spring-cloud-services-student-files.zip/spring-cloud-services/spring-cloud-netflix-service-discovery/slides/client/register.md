## Registering with Eureka

* When a client registers with Eureka, it provides meta-data about itself such as host and port, health indicator URL, home page etc.

* Eureka receives heartbeat messages from each instance belonging to a service. If the heartbeat fails over a configurable timetable, the instance is normally removed from the registry.
