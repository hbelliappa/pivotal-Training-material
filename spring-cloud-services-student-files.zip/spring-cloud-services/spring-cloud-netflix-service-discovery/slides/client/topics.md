<!-- .element: class="toc" -->

### Spring Cloud Netflix: Service Discovery

* Review Service Discovery
* Eureka Server
* Eureka Client <!-- .element: class="current-item" -->
* Spring Cloud Services

<i class="fa fa-cloud fa-lg"></i>
