## Spring Cloud Services: Service Registry


![service-registry](slides/resources/images/service-registry.png "service-registry")
