<!-- .element: class="textleft-imageright" -->
## Spring Cloud Services: Service Registry

1) Add dependency
```xml
<dependency>
  <groupId>io.pivotal.spring.cloud</groupId>
  <artifactId>spring-cloud-services-starter-service-registry</artifactId>
</dependency>
```


2) Create a Service Registry service instance


3) Bind the service to the app
