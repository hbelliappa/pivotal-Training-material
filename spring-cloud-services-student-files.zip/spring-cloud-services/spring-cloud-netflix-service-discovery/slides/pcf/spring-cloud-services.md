<!-- .element: class="textleft-imageright" -->
## Spring Cloud Services

![dashboard](slides/resources/images/scs.png "dashboard") <!-- .element style="width:auto;margin-right:20%" -->

* Brings Spring Cloud to Pivotal Cloud Foundry
* Includes: Config Server, Service Registry & Circuit Breaker Dashboard services
