<!-- .element: class="toc" -->

### Spring Cloud Netflix: Service Discovery

* Review Service Discovery
* Eureka Server
* Eureka Client
* Spring Cloud Services <!-- .element: class="current-item" -->

<i class="fa fa-cloud fa-lg"></i>
