## Challenge

* Service Discovery is one of the key tenets of a microservice based architecture.

* In distributed systems, application dependencies cease to be a method call away.

* Trying to hand configure each client or use some form of convention can be very difficult to do and can be very brittle.
