<!-- .element: class="toc" -->

### Spring Cloud Netflix: Service Discovery

* Review Service Discovery <!-- .element: class="current-item" -->
* Eureka Server
* Eureka Client
* Spring Cloud Services

<i class="fa fa-cloud fa-lg"></i>
