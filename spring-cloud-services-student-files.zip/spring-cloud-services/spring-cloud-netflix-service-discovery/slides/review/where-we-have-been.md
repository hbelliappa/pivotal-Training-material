## Where We Have Been

How have we discovered services in the past?


* Service Locators <!-- .element: style="padding-top:10px" -->
* Dependency Injection
* Service Registries
