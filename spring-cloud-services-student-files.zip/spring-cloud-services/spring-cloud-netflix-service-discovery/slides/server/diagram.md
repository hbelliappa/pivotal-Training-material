## Service Discovery with Spring Cloud

![service-discovery](slides/resources/images/service-discovery.png "service-discovery")
