<!-- .element: class="toc" -->

### Spring Cloud Netflix: Service Discovery

* Review Service Discovery
* Eureka Server <!-- .element: class="current-item" -->
* Eureka Client
* Spring Cloud Services

<i class="fa fa-cloud fa-lg"></i>
